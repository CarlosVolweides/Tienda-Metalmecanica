/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import Vistas.FormLogin;

/**
 *
 * @author User
 */
public class MainLogin {
    public static void main(String[] args){
        FormLogin objetoLogin = new FormLogin();
        objetoLogin.setVisible(true);
        
        }
        
    }
    
